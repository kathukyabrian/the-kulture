---
name: Nairobi Nights
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d4c0d7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9d8ba0'
  outline-variant: '#514255'
  surface-tint: '#ecb2ff'
  primary: '#ecb2ff'
  on-primary: '#520071'
  primary-container: '#bd00ff'
  on-primary-container: '#ffffff'
  inverse-primary: '#9900cf'
  secondary: '#a7ffb3'
  on-secondary: '#003915'
  secondary-container: '#00ee70'
  on-secondary-container: '#00662c'
  tertiary: '#ffb2bf'
  on-tertiary: '#660028'
  tertiary-container: '#e80063'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f8d8ff'
  primary-fixed-dim: '#ecb2ff'
  on-primary-fixed: '#320047'
  on-primary-fixed-variant: '#74009f'
  secondary-fixed: '#66ff8f'
  secondary-fixed-dim: '#00e46b'
  on-secondary-fixed: '#00210a'
  on-secondary-fixed-variant: '#005322'
  tertiary-fixed: '#ffd9de'
  tertiary-fixed-dim: '#ffb2bf'
  on-tertiary-fixed: '#3f0016'
  on-tertiary-fixed-variant: '#90003b'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Anybody
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Anybody
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Anybody
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 80px
---

## Brand & Style
The brand personality is electric, energetic, and urban. It captures the high-velocity spirit of Nairobi’s matatu culture—moving at the speed of light through a concrete jungle. The target audience consists of daily commuters, tech-savvy locals, and urban explorers who value speed, rhythm, and a distinct visual identity.

The design style is a hybrid of **Cyber-Brutalism** and **Vaporwave**. It uses deep charcoal surfaces to allow neon accents to "pop" with maximum luminance. Expect high-contrast interactions, glowing status indicators, and a rhythmic use of bold typography that mimics the hand-painted signage of a custom matatu.

## Colors
This design system utilizes a "Lights Out" dark mode foundation to emphasize its neon palette.

- **Backgrounds:** The primary canvas is a deep charcoal (#121212). Elevate surfaces using subtle tonal shifts rather than grey, maintaining the "night" atmosphere.
- **Electric Purple (Primary):** Used for primary actions, active route paths, and branding. It represents the night sky and neon signage.
- **Lime Green (Secondary):** Reserved for "Go," "On Time," and "Available" statuses. It provides the highest visibility against the dark background.
- **Hot Pink (Tertiary):** Used for alerts, live "ping" indicators, and high-energy accents.
- **Glow Effects:** Primary and secondary colors should utilize a 15-25% opacity drop-shadow/outer-glow to simulate neon gas tubes.

## Typography
The typography is designed to be loud and legible. 

- **Display & Headlines:** **Anybody** is used for its variable width and aggressive, sporty presence. Headlines should be set with tight tracking to feel dense and impactful.
- **Body Text:** **Hanken Grotesk** provides a clean, modern contrast to the expressive headlines, ensuring route names and timings remain perfectly legible.
- **Technical Data:** **JetBrains Mono** is used for timestamps, vehicle license plates (registration), and coordinates, giving a "tracking system" or "HUD" feel to the data.

## Layout & Spacing
The layout follows a strict 8px grid system to maintain order amidst the high-energy visual style.

- **Grid:** A 12-column fluid grid for desktop and a 4-column grid for mobile.
- **Rhythm:** Use "md" (24px) for most vertical stack spacing to give the bold typography room to breathe. 
- **Interactive Zones:** Ensure all touch targets for tracking controls follow a minimum 48px height.
- **Mobile-First:** Prioritize one-handed navigation, placing the most critical "Map" and "Search" functions within the bottom "thumb zone."

## Elevation & Depth
In this design system, depth is achieved through **Luminance and Inner Glows** rather than traditional shadows.

- **Surface Tiers:** Background is #121212. Elevated cards are #1E1E1E. Active/Focused cards use a 1px solid stroke of the Primary color with a subtle outer glow.
- **Neon Glow:** Use `box-shadow: 0 0 15px rgba(primary, 0.3)` for primary buttons and active indicators to create a sense of light emission.
- **Glassmorphism:** Use backdrop blurs (20px) on top navigation bars and bottom sheets to maintain a sense of the map beneath the UI, using a 60% opacity fill of the neutral color.

## Shapes
The shape language is "Hard-Modern." Elements use a **Soft (4px - 12px)** radius to feel engineered and precise, avoiding the bubbly nature of pill shapes.

- **Small elements (Buttons, Inputs):** 4px radius.
- **Containers (Cards, Bottom Sheets):** 12px radius.
- **Visual Accents:** Use 45-degree diagonal cuts on decorative corners to reinforce the "industrial" matatu aesthetic.

## Components

- **Buttons:** Primary buttons are solid Electric Purple with white or black text depending on contrast. They must have a subtle glow on hover/active states. Ghost buttons use a 1.5px Lime Green border.
- **Route Chips:** Small, high-contrast badges using JetBrains Mono. Route numbers should be bold and boxed (e.g., [ 111 ]).
- **Interactive Maps:** Use a custom dark-themed map tileset with Neon Purple for the "current route" and Neon Pink for the "live bus" icon.
- **Live Indicators:** A pulsating Hot Pink dot indicates a live-tracked matatu.
- **Cards:** Cards use #1E1E1E with no shadows. Instead, use a subtle "rim light" (a 1px top border at 20% opacity) to separate them from the background.
- **Input Fields:** Dark fills with a Lime Green bottom-border focus state. Label text should be uppercase and use the Mono font.
- **Lists:** High-density list items with 1px charcoal dividers. Every item should have a clear "chevron" or "action" icon in the secondary color.